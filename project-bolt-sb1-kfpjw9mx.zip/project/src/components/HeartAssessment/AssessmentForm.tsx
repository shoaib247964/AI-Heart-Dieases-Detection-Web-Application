import React, { useState } from 'react'
import { Heart, AlertCircle, CheckCircle, Activity, TrendingUp } from 'lucide-react'
import { HistoryRecord } from '../History/PatientHistory'

type AssessmentFormProps = {
  onComplete: (result: { score: number; risk: string; recommendations: string }) => void
}

export const AssessmentForm: React.FC<AssessmentFormProps> = ({ onComplete }) => {
  const [formData, setFormData] = useState({
    blood_pressure_systolic: '',
    blood_pressure_diastolic: '',
    cholesterol_level: '',
    age: '',
    smoking_status: false,
    diabetes_status: false,
    family_history: false,
    exercise_frequency: '',
    weight: '',
    height: '',
    symptoms: [] as string[]
  })
  const [loading, setLoading] = useState(false)

  const symptomsList = [
    'Chest pain or discomfort',
    'Shortness of breath',
    'Fatigue',
    'Irregular heartbeat',
    'Dizziness',
    'Nausea',
    'Sweating',
    'Pain in arms, neck, or jaw'
  ]

  const calculateBMI = (weight: number, height: number) => {
    const heightInMeters = height / 100
    return weight / (heightInMeters * heightInMeters)
  }

  const calculateRiskScore = () => {
    let score = 0
    const age = parseInt(formData.age)
    const systolic = parseInt(formData.blood_pressure_systolic)
    const cholesterol = parseInt(formData.cholesterol_level)
    const bmi = calculateBMI(parseFloat(formData.weight), parseFloat(formData.height))
    const exercise = parseInt(formData.exercise_frequency)

    // Age factor
    if (age > 65) score += 3
    else if (age > 55) score += 2
    else if (age > 45) score += 1

    // Blood pressure
    if (systolic > 140) score += 3
    else if (systolic > 130) score += 2
    else if (systolic > 120) score += 1

    // Cholesterol
    if (cholesterol > 240) score += 3
    else if (cholesterol > 200) score += 2
    else if (cholesterol > 180) score += 1

    // BMI
    if (bmi > 30) score += 2
    else if (bmi > 25) score += 1

    // Lifestyle factors
    if (formData.smoking_status) score += 3
    if (formData.diabetes_status) score += 2
    if (formData.family_history) score += 2
    if (exercise < 2) score += 2
    else if (exercise < 4) score += 1

    // Symptoms
    score += formData.symptoms.length * 0.5

    return Math.min(score, 20) // Cap at 20
  }

  const getRiskLevel = (score: number) => {
    if (score <= 5) return 'Low'
    if (score <= 10) return 'Moderate'
    if (score <= 15) return 'High'
    return 'Very High'
  }

  const getRecommendations = (score: number, riskLevel: string) => {
    const recommendations = []
    
    if (formData.smoking_status) {
      recommendations.push('Quit smoking immediately - this is the most important step you can take.')
    }
    
    if (parseInt(formData.exercise_frequency) < 4) {
      recommendations.push('Increase physical activity to at least 30 minutes, 5 days per week.')
    }
    
    if (calculateBMI(parseFloat(formData.weight), parseFloat(formData.height)) > 25) {
      recommendations.push('Maintain a healthy weight through diet and exercise.')
    }
    
    if (parseInt(formData.blood_pressure_systolic) > 130) {
      recommendations.push('Monitor and manage blood pressure through medication if needed.')
    }
    
    if (parseInt(formData.cholesterol_level) > 200) {
      recommendations.push('Follow a heart-healthy diet low in saturated fats and cholesterol.')
    }
    
    if (riskLevel === 'High' || riskLevel === 'Very High') {
      recommendations.push('Schedule regular check-ups with a cardiologist.')
      recommendations.push('Consider stress management techniques like meditation or yoga.')
    }
    
    recommendations.push('Take prescribed medications as directed by your healthcare provider.')
    
    return recommendations.join(' ')
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    // Simulate processing time
    setTimeout(() => {
      const score = calculateRiskScore()
      const riskLevel = getRiskLevel(score)
      const recommendations = getRecommendations(score, riskLevel)
      const bmi = calculateBMI(parseFloat(formData.weight), parseFloat(formData.height))

      // Save to history
      const historyRecord: Omit<HistoryRecord, 'id'> = {
        date: new Date().toISOString(),
        score,
        risk: riskLevel,
        recommendations,
        bloodPressureSystolic: parseInt(formData.blood_pressure_systolic),
        bloodPressureDiastolic: parseInt(formData.blood_pressure_diastolic),
        cholesterolLevel: parseInt(formData.cholesterol_level),
        age: parseInt(formData.age),
        bmi,
        smokingStatus: formData.smoking_status,
        diabetesStatus: formData.diabetes_status,
        familyHistory: formData.family_history,
        exerciseFrequency: parseInt(formData.exercise_frequency),
        symptoms: formData.symptoms
      }

      // Add to history if the function is available
      if ((window as any).addHistoryRecord) {
        (window as any).addHistoryRecord(historyRecord)
      }

      onComplete({ score, risk: riskLevel, recommendations })
      setLoading(false)
    }, 2000)
  }

  const handleSymptomChange = (symptom: string) => {
    setFormData(prev => ({
      ...prev,
      symptoms: prev.symptoms.includes(symptom)
        ? prev.symptoms.filter(s => s !== symptom)
        : [...prev.symptoms, symptom]
    }))
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    }))
  }

  return (
    <div className="max-w-4xl mx-auto p-8">
      <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-teal-600 p-8 text-white">
          <div className="text-center">
            <div className="flex justify-center mb-6">
              <div className="p-4 bg-white/20 rounded-full backdrop-blur-sm">
                <Heart className="h-12 w-12" />
              </div>
            </div>
            <h2 className="text-4xl font-bold mb-3">
              Heart Health Assessment
            </h2>
            <p className="text-xl text-blue-100">
              Advanced cardiovascular risk evaluation powered by medical algorithms
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-8">
          {/* Personal Information */}
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-gray-800 flex items-center">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                <span className="text-blue-600 font-bold">1</span>
              </div>
              Personal Information
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="block text-sm font-semibold text-gray-700">
                  Age
                </label>
                <input
                  type="number"
                  name="age"
                  required
                  value={formData.age}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition-all duration-200"
                  placeholder="Enter your age"
                />
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-semibold text-gray-700">
                  Exercise Frequency (days/week)
                </label>
                <select
                  name="exercise_frequency"
                  required
                  value={formData.exercise_frequency}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition-all duration-200"
                >
                  <option value="">Select frequency</option>
                  <option value="0">Never</option>
                  <option value="1">1 day</option>
                  <option value="2">2 days</option>
                  <option value="3">3 days</option>
                  <option value="4">4 days</option>
                  <option value="5">5 days</option>
                  <option value="6">6 days</option>
                  <option value="7">Every day</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="block text-sm font-semibold text-gray-700">
                  Weight (kg)
                </label>
                <input
                  type="number"
                  name="weight"
                  required
                  value={formData.weight}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition-all duration-200"
                  placeholder="e.g., 70"
                />
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-semibold text-gray-700">
                  Height (cm)
                </label>
                <input
                  type="number"
                  name="height"
                  required
                  value={formData.height}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition-all duration-200"
                  placeholder="e.g., 170"
                />
              </div>
            </div>
          </div>

          {/* Medical Measurements */}
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-gray-800 flex items-center">
              <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center mr-3">
                <span className="text-purple-600 font-bold">2</span>
              </div>
              Medical Measurements
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="block text-sm font-semibold text-gray-700">
                  Blood Pressure (Systolic)
                </label>
                <input
                  type="number"
                  name="blood_pressure_systolic"
                  required
                  value={formData.blood_pressure_systolic}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-purple-500 focus:ring-4 focus:ring-purple-100 transition-all duration-200"
                  placeholder="e.g., 120"
                />
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-semibold text-gray-700">
                  Blood Pressure (Diastolic)
                </label>
                <input
                  type="number"
                  name="blood_pressure_diastolic"
                  required
                  value={formData.blood_pressure_diastolic}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-purple-500 focus:ring-4 focus:ring-purple-100 transition-all duration-200"
                  placeholder="e.g., 80"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-semibold text-gray-700">
                Cholesterol Level (mg/dL)
              </label>
              <input
                type="number"
                name="cholesterol_level"
                required
                value={formData.cholesterol_level}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-purple-500 focus:ring-4 focus:ring-purple-100 transition-all duration-200"
                placeholder="e.g., 180"
              />
            </div>
          </div>

          {/* Health Conditions */}
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-gray-800 flex items-center">
              <div className="w-8 h-8 bg-teal-100 rounded-full flex items-center justify-center mr-3">
                <span className="text-teal-600 font-bold">3</span>
              </div>
              Health Conditions
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-6 bg-gradient-to-br from-red-50 to-red-100 rounded-2xl border-2 border-red-200">
                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    name="smoking_status"
                    checked={formData.smoking_status}
                    onChange={handleChange}
                    className="h-5 w-5 text-red-600 focus:ring-red-500 border-red-300 rounded"
                  />
                  <label className="text-sm font-semibold text-red-800">
                    I currently smoke or have smoked
                  </label>
                </div>
              </div>

              <div className="p-6 bg-gradient-to-br from-orange-50 to-orange-100 rounded-2xl border-2 border-orange-200">
                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    name="diabetes_status"
                    checked={formData.diabetes_status}
                    onChange={handleChange}
                    className="h-5 w-5 text-orange-600 focus:ring-orange-500 border-orange-300 rounded"
                  />
                  <label className="text-sm font-semibold text-orange-800">
                    I have diabetes
                  </label>
                </div>
              </div>

              <div className="p-6 bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-2xl border-2 border-yellow-200">
                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    name="family_history"
                    checked={formData.family_history}
                    onChange={handleChange}
                    className="h-5 w-5 text-yellow-600 focus:ring-yellow-500 border-yellow-300 rounded"
                  />
                  <label className="text-sm font-semibold text-yellow-800">
                    Family history of heart disease
                  </label>
                </div>
              </div>
            </div>
          </div>

          {/* Symptoms */}
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-gray-800 flex items-center">
              <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mr-3">
                <span className="text-green-600 font-bold">4</span>
              </div>
              Current Symptoms
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {symptomsList.map((symptom) => (
                <div key={symptom} className="p-4 bg-gray-50 rounded-xl border-2 border-gray-200 hover:border-green-300 transition-all duration-200">
                  <div className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={formData.symptoms.includes(symptom)}
                      onChange={() => handleSymptomChange(symptom)}
                      className="h-5 w-5 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                    />
                    <label className="text-sm font-medium text-gray-700">
                      {symptom}
                    </label>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Submit Button */}
          <div className="pt-8">
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-blue-600 via-purple-600 to-teal-600 hover:from-blue-700 hover:via-purple-700 hover:to-teal-700 text-white font-bold py-4 px-8 rounded-2xl disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105 shadow-xl"
            >
              {loading ? (
                <div className="flex items-center justify-center space-x-3">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
                  <span>Analyzing Your Heart Health...</span>
                </div>
              ) : (
                <div className="flex items-center justify-center space-x-3">
                  <Activity className="h-6 w-6" />
                  <span>Get My Heart Health Assessment</span>
                </div>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}