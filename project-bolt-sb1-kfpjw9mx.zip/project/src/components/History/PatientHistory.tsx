import React, { useState, useEffect } from 'react'
import { History, Edit, Trash2, Calendar, Heart, TrendingUp, Plus, Search, Filter } from 'lucide-react'

export type HistoryRecord = {
  id: string
  date: string
  score: number
  risk: string
  recommendations: string
  bloodPressureSystolic: number
  bloodPressureDiastolic: number
  cholesterolLevel: number
  age: number
  bmi: number
  smokingStatus: boolean
  diabetesStatus: boolean
  familyHistory: boolean
  exerciseFrequency: number
  symptoms: string[]
}

type PatientHistoryProps = {
  onTakeNewAssessment: () => void
}

export const PatientHistory: React.FC<PatientHistoryProps> = ({ onTakeNewAssessment }) => {
  const [records, setRecords] = useState<HistoryRecord[]>([])
  const [editingRecord, setEditingRecord] = useState<HistoryRecord | null>(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [riskFilter, setRiskFilter] = useState<'all' | 'low' | 'moderate' | 'high' | 'very high'>('all')

  useEffect(() => {
    loadHistoryFromStorage()
  }, [])

  const loadHistoryFromStorage = () => {
    const stored = localStorage.getItem('heartDiseaseHistory')
    if (stored) {
      setRecords(JSON.parse(stored))
    }
  }

  const saveHistoryToStorage = (newRecords: HistoryRecord[]) => {
    localStorage.setItem('heartDiseaseHistory', JSON.stringify(newRecords))
    setRecords(newRecords)
  }

  const addRecord = (record: Omit<HistoryRecord, 'id'>) => {
    const newRecord: HistoryRecord = {
      ...record,
      id: Date.now().toString()
    }
    const newRecords = [newRecord, ...records]
    saveHistoryToStorage(newRecords)
  }

  const updateRecord = (updatedRecord: HistoryRecord) => {
    const newRecords = records.map(record => 
      record.id === updatedRecord.id ? updatedRecord : record
    )
    saveHistoryToStorage(newRecords)
    setEditingRecord(null)
  }

  const deleteRecord = (id: string) => {
    if (window.confirm('Are you sure you want to delete this assessment record?')) {
      const newRecords = records.filter(record => record.id !== id)
      saveHistoryToStorage(newRecords)
    }
  }

  const getRiskColor = (risk: string) => {
    switch (risk.toLowerCase()) {
      case 'low':
        return 'text-green-600 bg-green-100 border-green-200'
      case 'moderate':
        return 'text-yellow-600 bg-yellow-100 border-yellow-200'
      case 'high':
        return 'text-orange-600 bg-orange-100 border-orange-200'
      default:
        return 'text-red-600 bg-red-100 border-red-200'
    }
  }

  const filteredRecords = records.filter(record => {
    const matchesSearch = record.date.includes(searchTerm) || 
                         record.risk.toLowerCase().includes(searchTerm.toLowerCase())
    
    if (!matchesSearch) return false

    if (riskFilter === 'all') return true
    return record.risk.toLowerCase() === riskFilter
  })

  // Expose addRecord function globally so AssessmentForm can use it
  React.useEffect(() => {
    (window as any).addHistoryRecord = addRecord
  }, [records])

  return (
    <div className="max-w-7xl mx-auto p-8">
      <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-teal-600 p-8 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-white/20 rounded-full backdrop-blur-sm">
                <History className="h-8 w-8" />
              </div>
              <div>
                <h2 className="text-3xl font-bold">Patient History</h2>
                <p className="text-blue-100">Manage your heart health assessment records</p>
              </div>
            </div>
            <button
              onClick={onTakeNewAssessment}
              className="px-6 py-3 bg-white/20 hover:bg-white/30 rounded-xl backdrop-blur-sm transition-all duration-200 transform hover:scale-105"
            >
              <div className="flex items-center space-x-2">
                <Plus className="h-5 w-5" />
                <span>New Assessment</span>
              </div>
            </button>
          </div>
        </div>

        {/* Search and Filter */}
        <div className="p-6 border-b bg-gray-50">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
            <div className="relative flex-1 max-w-md">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search records..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 block w-full rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition-all duration-200"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Filter className="h-5 w-5 text-gray-400" />
              <select
                value={riskFilter}
                onChange={(e) => setRiskFilter(e.target.value as any)}
                className="rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition-all duration-200"
              >
                <option value="all">All Risk Levels</option>
                <option value="low">Low Risk</option>
                <option value="moderate">Moderate Risk</option>
                <option value="high">High Risk</option>
                <option value="very high">Very High Risk</option>
              </select>
            </div>
          </div>
        </div>

        {/* Records List */}
        <div className="p-6">
          {filteredRecords.length === 0 ? (
            <div className="text-center py-16">
              <div className="flex justify-center mb-6">
                <div className="p-6 bg-gray-100 rounded-full">
                  <Heart className="h-16 w-16 text-gray-400" />
                </div>
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">No Assessment Records</h3>
              <p className="text-gray-600 mb-8 max-w-md mx-auto">
                Start tracking your heart health by taking your first assessment.
              </p>
              <button
                onClick={onTakeNewAssessment}
                className="px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-bold rounded-2xl hover:from-blue-700 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg"
              >
                <div className="flex items-center space-x-2">
                  <Plus className="h-5 w-5" />
                  <span>Take First Assessment</span>
                </div>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {filteredRecords.map((record) => (
                <div key={record.id} className="bg-gradient-to-br from-white to-gray-50 rounded-2xl p-6 border-2 border-gray-100 hover:shadow-xl transition-all duration-300 transform hover:scale-105">
                  {/* Record Header */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-blue-100 rounded-lg">
                        <Calendar className="h-5 w-5 text-blue-600" />
                      </div>
                      <div>
                        <p className="font-bold text-gray-800">{new Date(record.date).toLocaleDateString()}</p>
                        <p className="text-sm text-gray-600">{new Date(record.date).toLocaleTimeString()}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => setEditingRecord(record)}
                        className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg transition-all duration-200"
                      >
                        <Edit className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => deleteRecord(record.id)}
                        className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition-all duration-200"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>

                  {/* Risk Score */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="relative w-16 h-16">
                        <svg className="w-16 h-16 transform -rotate-90" viewBox="0 0 100 100">
                          <circle
                            cx="50"
                            cy="50"
                            r="35"
                            stroke="#e5e7eb"
                            strokeWidth="6"
                            fill="none"
                          />
                          <circle
                            cx="50"
                            cy="50"
                            r="35"
                            stroke="#3b82f6"
                            strokeWidth="6"
                            fill="none"
                            strokeDasharray={`${(record.score / 20) * 220} 220`}
                          />
                        </svg>
                        <div className="absolute inset-0 flex items-center justify-center">
                          <span className="text-lg font-bold text-blue-600">{record.score}</span>
                        </div>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Risk Score</p>
                        <p className="font-bold text-gray-800">{record.score}/20</p>
                      </div>
                    </div>
                    <div className={`px-4 py-2 rounded-full text-sm font-bold border-2 ${getRiskColor(record.risk)}`}>
                      {record.risk} Risk
                    </div>
                  </div>

                  {/* Health Metrics */}
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="bg-white rounded-lg p-3 border">
                      <p className="text-xs text-gray-600">Blood Pressure</p>
                      <p className="font-bold text-gray-800">{record.bloodPressureSystolic}/{record.bloodPressureDiastolic}</p>
                    </div>
                    <div className="bg-white rounded-lg p-3 border">
                      <p className="text-xs text-gray-600">Cholesterol</p>
                      <p className="font-bold text-gray-800">{record.cholesterolLevel} mg/dL</p>
                    </div>
                    <div className="bg-white rounded-lg p-3 border">
                      <p className="text-xs text-gray-600">BMI</p>
                      <p className="font-bold text-gray-800">{record.bmi.toFixed(1)}</p>
                    </div>
                    <div className="bg-white rounded-lg p-3 border">
                      <p className="text-xs text-gray-600">Age</p>
                      <p className="font-bold text-gray-800">{record.age} years</p>
                    </div>
                  </div>

                  {/* Health Conditions */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    {record.smokingStatus && (
                      <span className="px-2 py-1 bg-red-100 text-red-800 text-xs rounded-full">Smoker</span>
                    )}
                    {record.diabetesStatus && (
                      <span className="px-2 py-1 bg-orange-100 text-orange-800 text-xs rounded-full">Diabetes</span>
                    )}
                    {record.familyHistory && (
                      <span className="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded-full">Family History</span>
                    )}
                    <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                      Exercise: {record.exerciseFrequency}x/week
                    </span>
                  </div>

                  {/* Symptoms */}
                  {record.symptoms.length > 0 && (
                    <div className="mb-4">
                      <p className="text-sm font-semibold text-gray-700 mb-2">Symptoms:</p>
                      <div className="flex flex-wrap gap-1">
                        {record.symptoms.slice(0, 3).map((symptom, index) => (
                          <span key={index} className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                            {symptom}
                          </span>
                        ))}
                        {record.symptoms.length > 3 && (
                          <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full">
                            +{record.symptoms.length - 3} more
                          </span>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Edit Modal */}
      {editingRecord && (
        <EditRecordModal
          record={editingRecord}
          onSave={updateRecord}
          onCancel={() => setEditingRecord(null)}
        />
      )}
    </div>
  )
}

type EditRecordModalProps = {
  record: HistoryRecord
  onSave: (record: HistoryRecord) => void
  onCancel: () => void
}

const EditRecordModal: React.FC<EditRecordModalProps> = ({ record, onSave, onCancel }) => {
  const [editedRecord, setEditedRecord] = useState<HistoryRecord>(record)

  const handleSave = () => {
    onSave(editedRecord)
  }

  const handleChange = (field: keyof HistoryRecord, value: any) => {
    setEditedRecord(prev => ({
      ...prev,
      [field]: value
    }))
  }

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-6 text-white">
          <h3 className="text-2xl font-bold">Edit Assessment Record</h3>
          <p className="text-blue-100">Update your health assessment details</p>
        </div>

        {/* Modal Content */}
        <div className="p-6 space-y-6">
          {/* Basic Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Age</label>
              <input
                type="number"
                value={editedRecord.age}
                onChange={(e) => handleChange('age', parseInt(e.target.value))}
                className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition-all duration-200"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">BMI</label>
              <input
                type="number"
                step="0.1"
                value={editedRecord.bmi}
                onChange={(e) => handleChange('bmi', parseFloat(e.target.value))}
                className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition-all duration-200"
              />
            </div>
          </div>

          {/* Blood Pressure */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Systolic BP</label>
              <input
                type="number"
                value={editedRecord.bloodPressureSystolic}
                onChange={(e) => handleChange('bloodPressureSystolic', parseInt(e.target.value))}
                className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition-all duration-200"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Diastolic BP</label>
              <input
                type="number"
                value={editedRecord.bloodPressureDiastolic}
                onChange={(e) => handleChange('bloodPressureDiastolic', parseInt(e.target.value))}
                className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition-all duration-200"
              />
            </div>
          </div>

          {/* Cholesterol and Exercise */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Cholesterol (mg/dL)</label>
              <input
                type="number"
                value={editedRecord.cholesterolLevel}
                onChange={(e) => handleChange('cholesterolLevel', parseInt(e.target.value))}
                className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition-all duration-200"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Exercise Frequency (days/week)</label>
              <input
                type="number"
                min="0"
                max="7"
                value={editedRecord.exerciseFrequency}
                onChange={(e) => handleChange('exerciseFrequency', parseInt(e.target.value))}
                className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition-all duration-200"
              />
            </div>
          </div>

          {/* Health Conditions */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-gray-800">Health Conditions</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex items-center space-x-3 p-4 bg-gray-50 rounded-xl">
                <input
                  type="checkbox"
                  checked={editedRecord.smokingStatus}
                  onChange={(e) => handleChange('smokingStatus', e.target.checked)}
                  className="h-5 w-5 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <label className="text-sm font-medium text-gray-700">Smoking</label>
              </div>
              <div className="flex items-center space-x-3 p-4 bg-gray-50 rounded-xl">
                <input
                  type="checkbox"
                  checked={editedRecord.diabetesStatus}
                  onChange={(e) => handleChange('diabetesStatus', e.target.checked)}
                  className="h-5 w-5 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <label className="text-sm font-medium text-gray-700">Diabetes</label>
              </div>
              <div className="flex items-center space-x-3 p-4 bg-gray-50 rounded-xl">
                <input
                  type="checkbox"
                  checked={editedRecord.familyHistory}
                  onChange={(e) => handleChange('familyHistory', e.target.checked)}
                  className="h-5 w-5 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <label className="text-sm font-medium text-gray-700">Family History</label>
              </div>
            </div>
          </div>

          {/* Recommendations */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Recommendations</label>
            <textarea
              value={editedRecord.recommendations}
              onChange={(e) => handleChange('recommendations', e.target.value)}
              rows={4}
              className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition-all duration-200"
            />
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-6 border-t bg-gray-50 flex justify-end space-x-4">
          <button
            onClick={onCancel}
            className="px-6 py-3 bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold rounded-xl transition-all duration-200"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold rounded-xl transition-all duration-200 transform hover:scale-105"
          >
            Save Changes
          </button>
        </div>
      </div>
    </div>
  )
}