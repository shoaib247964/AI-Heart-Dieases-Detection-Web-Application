import React, { useState, useEffect, useRef } from 'react'
import { Send, Bot, User, Heart, Sparkles } from 'lucide-react'

type Message = {
  id: string
  content: string
  sender: 'user' | 'bot'
  timestamp: Date
}

export const ChatBot: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([])
  const [inputMessage, setInputMessage] = useState('')
  const [loading, setLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Initialize with welcome message
    setMessages([
      {
        id: '1',
        content: "Hello! I'm your CardioHealth AI assistant. I can help you understand heart health, provide lifestyle recommendations, and answer questions about cardiovascular wellness. How can I assist you today?",
        sender: 'bot',
        timestamp: new Date()
      }
    ])
  }, [])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  const generateBotResponse = (userMessage: string): string => {
    const message = userMessage.toLowerCase()
    
    // Heart disease related responses
    if (message.includes('heart') || message.includes('cardiac') || message.includes('cardiovascular')) {
      if (message.includes('risk') || message.includes('prevent')) {
        return "To reduce heart disease risk, focus on: 1) Regular exercise (150 minutes/week), 2) Heart-healthy diet (low in saturated fats, high in fruits/vegetables), 3) Maintain healthy weight, 4) Don't smoke, 5) Limit alcohol, 6) Manage stress, 7) Get regular check-ups. Would you like specific information about any of these areas?"
      }
      if (message.includes('symptoms') || message.includes('signs')) {
        return "Common heart disease symptoms include: chest pain/discomfort, shortness of breath, fatigue, irregular heartbeat, dizziness, nausea, and pain in arms/neck/jaw. If you experience severe chest pain, call emergency services immediately. For ongoing symptoms, consult your doctor."
      }
      if (message.includes('exercise') || message.includes('activity')) {
        return "Heart-healthy exercises include: brisk walking, swimming, cycling, and strength training. Start with 30 minutes of moderate activity 5 days a week. Always consult your doctor before starting a new exercise program, especially if you have existing heart conditions."
      }
    }
    
    // Blood pressure related
    if (message.includes('blood pressure') || message.includes('hypertension')) {
      return "Normal blood pressure is less than 120/80 mmHg. To maintain healthy blood pressure: reduce sodium intake, exercise regularly, maintain healthy weight, limit alcohol, manage stress, and don't smoke. If your blood pressure is consistently high, work with your doctor on a treatment plan."
    }
    
    // Cholesterol related
    if (message.includes('cholesterol')) {
      return "Healthy cholesterol levels: Total cholesterol <200 mg/dL, LDL <100 mg/dL, HDL >40 mg/dL (men) or >50 mg/dL (women). To improve cholesterol: eat foods high in soluble fiber, choose healthy fats, exercise regularly, maintain healthy weight, and avoid trans fats."
    }
    
    // Diet related
    if (message.includes('diet') || message.includes('food') || message.includes('nutrition')) {
      return "A heart-healthy diet includes: lots of fruits and vegetables, whole grains, lean proteins (fish, poultry, beans), healthy fats (olive oil, nuts, avocados), and limited processed foods, saturated fats, and added sugars. The Mediterranean diet is particularly beneficial for heart health."
    }
    
    // Stress related
    if (message.includes('stress') || message.includes('anxiety')) {
      return "Chronic stress can impact heart health. Stress management techniques include: deep breathing exercises, meditation, yoga, regular exercise, adequate sleep, social support, and professional counseling if needed. Finding healthy ways to cope with stress is important for overall cardiovascular health."
    }
    
    // Smoking related
    if (message.includes('smoking') || message.includes('tobacco')) {
      return "Smoking is a major risk factor for heart disease. Quitting smoking provides immediate and long-term benefits: within 20 minutes, heart rate and blood pressure drop; within 1 year, risk of heart disease is cut in half. Resources for quitting include nicotine replacement therapy, prescription medications, and support groups."
    }
    
    // General health responses
    if (message.includes('hello') || message.includes('hi')) {
      return "Hello! I'm here to help with your cardiovascular health questions. You can ask me about heart disease prevention, symptoms, lifestyle recommendations, or any other heart health topics."
    }
    
    if (message.includes('emergency') || message.includes('chest pain') || message.includes('heart attack')) {
      return "⚠️ EMERGENCY: If you're experiencing severe chest pain, shortness of breath, or think you're having a heart attack, call emergency services (911) immediately. Don't wait or drive yourself to the hospital. Time is critical in heart emergencies."
    }
    
    // Default response
    return "I'm here to help with heart health questions. You can ask me about heart disease prevention, symptoms, diet, exercise, blood pressure, cholesterol, or any other cardiovascular health topics. What would you like to know?"
  }

  const sendMessage = async () => {
    if (!inputMessage.trim()) return
    
    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputMessage,
      sender: 'user',
      timestamp: new Date()
    }
    
    setMessages(prev => [...prev, userMessage])
    setInputMessage('')
    setLoading(true)
    
    // Generate bot response with realistic delay
    setTimeout(() => {
      const botResponse = generateBotResponse(inputMessage)
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: botResponse,
        sender: 'bot',
        timestamp: new Date()
      }
      
      setMessages(prev => [...prev, botMessage])
      setLoading(false)
    }, 1500)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  return (
    <div className="max-w-4xl mx-auto p-8">
      <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-teal-600 text-white p-8">
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-white/20 rounded-full backdrop-blur-sm">
              <Bot className="h-8 w-8" />
            </div>
            <div>
              <h2 className="text-2xl font-bold">CardioHealth AI Assistant</h2>
              <p className="text-blue-100">Get personalized heart health guidance and support</p>
            </div>
            <div className="ml-auto">
              <Sparkles className="h-6 w-6 text-yellow-300 animate-pulse" />
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="h-96 overflow-y-auto p-6 space-y-6 bg-gradient-to-b from-gray-50 to-white">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-xs lg:max-w-md px-6 py-4 rounded-2xl shadow-lg ${
                  message.sender === 'user'
                    ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white'
                    : 'bg-white text-gray-800 border-2 border-gray-100'
                }`}
              >
                <div className="flex items-start space-x-3">
                  {message.sender === 'bot' && (
                    <div className="flex-shrink-0 w-8 h-8 bg-gradient-to-r from-blue-500 to-teal-500 rounded-full flex items-center justify-center">
                      <Bot className="h-4 w-4 text-white" />
                    </div>
                  )}
                  {message.sender === 'user' && (
                    <div className="flex-shrink-0 w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                      <User className="h-4 w-4 text-white" />
                    </div>
                  )}
                  <div className="flex-1">
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
                    <p className={`text-xs mt-2 ${
                      message.sender === 'user' ? 'text-blue-100' : 'text-gray-500'
                    }`}>
                      {message.timestamp.toLocaleTimeString()}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ))}
          
          {loading && (
            <div className="flex justify-start">
              <div className="bg-white text-gray-800 px-6 py-4 rounded-2xl shadow-lg border-2 border-gray-100">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-teal-500 rounded-full flex items-center justify-center">
                    <Bot className="h-4 w-4 text-white" />
                  </div>
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                    <div className="w-2 h-2 bg-teal-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="border-t-2 border-gray-100 p-6 bg-white">
          <div className="flex space-x-4">
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask me about heart health..."
              className="flex-1 px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition-all duration-200"
              disabled={loading}
            />
            <button
              onClick={sendMessage}
              disabled={loading || !inputMessage.trim()}
              className="px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl hover:from-blue-700 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 transform hover:scale-105 shadow-lg"
            >
              <Send className="h-5 w-5" />
            </button>
          </div>
          
          {/* Quick Actions */}
          <div className="mt-4 flex flex-wrap gap-2">
            <button
              onClick={() => setInputMessage("What are the symptoms of heart disease?")}
              className="px-4 py-2 bg-gradient-to-r from-blue-100 to-blue-200 text-blue-800 rounded-full text-sm hover:from-blue-200 hover:to-blue-300 transition-all duration-200 transform hover:scale-105"
            >
              Heart Disease Symptoms
            </button>
            <button
              onClick={() => setInputMessage("How can I reduce my heart disease risk?")}
              className="px-4 py-2 bg-gradient-to-r from-green-100 to-green-200 text-green-800 rounded-full text-sm hover:from-green-200 hover:to-green-300 transition-all duration-200 transform hover:scale-105"
            >
              Prevention Tips
            </button>
            <button
              onClick={() => setInputMessage("What should I eat for heart health?")}
              className="px-4 py-2 bg-gradient-to-r from-purple-100 to-purple-200 text-purple-800 rounded-full text-sm hover:from-purple-200 hover:to-purple-300 transition-all duration-200 transform hover:scale-105"
            >
              Heart-Healthy Diet
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}