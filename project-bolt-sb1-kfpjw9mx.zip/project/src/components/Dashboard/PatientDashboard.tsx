import React, { useState, useEffect } from 'react'
import { useAuth } from '../../context/AuthContext'
import { supabase } from '../../lib/supabase'
import { AssessmentForm } from '../HeartAssessment/AssessmentForm'
import { ChatBot } from '../Chat/ChatBot'
import { 
  Heart, 
  Activity, 
  TrendingUp, 
  Calendar, 
  User, 
  MessageCircle,
  Plus,
  AlertCircle
} from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

type MedicalRecord = {
  id: string
  assessment_date: string
  heart_disease_risk_score: number
  blood_pressure_systolic: number
  blood_pressure_diastolic: number
  cholesterol_level: number
  bmi: number
  recommendations: string
}

export const PatientDashboard: React.FC = () => {
  const { profile, signOut } = useAuth()
  const [records, setRecords] = useState<MedicalRecord[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<'overview' | 'assessment' | 'chat'>('overview')

  useEffect(() => {
    fetchRecords()
  }, [])

  const fetchRecords = async () => {
    try {
      const { data, error } = await supabase
        .from('medical_records')
        .select('*')
        .order('assessment_date', { ascending: false })

      if (error) throw error
      setRecords(data || [])
    } catch (error) {
      console.error('Error fetching records:', error)
    } finally {
      setLoading(false)
    }
  }

  const latestRecord = records[0]
  const chartData = records.slice(0, 6).reverse().map(record => ({
    date: new Date(record.assessment_date).toLocaleDateString(),
    score: record.heart_disease_risk_score,
    systolic: record.blood_pressure_systolic,
    cholesterol: record.cholesterol_level
  }))

  const getRiskColor = (score: number) => {
    if (score <= 5) return 'text-green-600 bg-green-100'
    if (score <= 10) return 'text-yellow-600 bg-yellow-100'
    if (score <= 15) return 'text-orange-600 bg-orange-100'
    return 'text-red-600 bg-red-100'
  }

  const getRiskLevel = (score: number) => {
    if (score <= 5) return 'Low'
    if (score <= 10) return 'Moderate'
    if (score <= 15) return 'High'
    return 'Very High'
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Heart className="h-12 w-12 text-blue-600 mx-auto mb-4 animate-pulse" />
          <p className="text-gray-600">Loading your health data...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Heart className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">CardioHealth</span>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-sm text-gray-600">
                Welcome, {profile?.full_name}
              </div>
              <button
                onClick={signOut}
                className="text-sm text-gray-600 hover:text-gray-900"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8">
            <button
              onClick={() => setActiveTab('overview')}
              className={`py-3 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'overview'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => setActiveTab('assessment')}
              className={`py-3 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'assessment'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              New Assessment
            </button>
            <button
              onClick={() => setActiveTab('chat')}
              className={`py-3 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'chat'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Health Assistant
            </button>
          </div>
        </div>
      </nav>

      {/* Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Health Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <Heart className="h-6 w-6 text-blue-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm text-gray-600">Risk Score</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {latestRecord ? `${latestRecord.heart_disease_risk_score}/20` : 'N/A'}
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center">
                  <div className="p-2 bg-green-100 rounded-lg">
                    <Activity className="h-6 w-6 text-green-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm text-gray-600">Blood Pressure</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {latestRecord ? `${latestRecord.blood_pressure_systolic}/${latestRecord.blood_pressure_diastolic}` : 'N/A'}
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center">
                  <div className="p-2 bg-yellow-100 rounded-lg">
                    <TrendingUp className="h-6 w-6 text-yellow-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm text-gray-600">Cholesterol</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {latestRecord ? `${latestRecord.cholesterol_level} mg/dL` : 'N/A'}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Risk Status */}
            {latestRecord && (
              <div className="bg-white rounded-lg shadow p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Current Risk Status</h3>
                <div className="flex items-center space-x-4">
                  <div className={`px-4 py-2 rounded-full text-sm font-medium ${getRiskColor(latestRecord.heart_disease_risk_score)}`}>
                    {getRiskLevel(latestRecord.heart_disease_risk_score)} Risk
                  </div>
                  <div className="text-sm text-gray-600">
                    Last assessed: {new Date(latestRecord.assessment_date).toLocaleDateString()}
                  </div>
                </div>
                <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-700">{latestRecord.recommendations}</p>
                </div>
              </div>
            )}

            {/* Charts */}
            {chartData.length > 0 && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white rounded-lg shadow p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Risk Score Trend</h3>
                  <ResponsiveContainer width="100%" height={200}>
                    <LineChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Line 
                        type="monotone" 
                        dataKey="score" 
                        stroke="#2563eb" 
                        strokeWidth={2}
                        dot={{ fill: '#2563eb' }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>

                <div className="bg-white rounded-lg shadow p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Blood Pressure Trend</h3>
                  <ResponsiveContainer width="100%" height={200}>
                    <LineChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Line 
                        type="monotone" 
                        dataKey="systolic" 
                        stroke="#dc2626" 
                        strokeWidth={2}
                        dot={{ fill: '#dc2626' }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}

            {/* Recent Assessments */}
            <div className="bg-white rounded-lg shadow">
              <div className="p-6 border-b">
                <h3 className="text-lg font-semibold text-gray-900">Recent Assessments</h3>
              </div>
              <div className="p-6">
                {records.length === 0 ? (
                  <div className="text-center py-8">
                    <Heart className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">No assessments yet</p>
                    <button
                      onClick={() => setActiveTab('assessment')}
                      className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Take Your First Assessment
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {records.slice(0, 5).map((record) => (
                      <div key={record.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="p-2 bg-blue-100 rounded-lg">
                            <Calendar className="h-5 w-5 text-blue-600" />
                          </div>
                          <div>
                            <p className="font-medium text-gray-900">
                              {new Date(record.assessment_date).toLocaleDateString()}
                            </p>
                            <p className="text-sm text-gray-600">
                              Risk Score: {record.heart_disease_risk_score}/20
                            </p>
                          </div>
                        </div>
                        <div className={`px-3 py-1 rounded-full text-sm font-medium ${getRiskColor(record.heart_disease_risk_score)}`}>
                          {getRiskLevel(record.heart_disease_risk_score)}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'assessment' && (
          <AssessmentForm onComplete={() => {
            setActiveTab('overview')
            fetchRecords()
          }} />
        )}

        {activeTab === 'chat' && (
          <ChatBot />
        )}
      </main>
    </div>
  )
}