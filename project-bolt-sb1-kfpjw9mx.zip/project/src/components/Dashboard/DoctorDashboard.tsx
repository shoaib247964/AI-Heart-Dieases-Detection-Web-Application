import React, { useState, useEffect } from 'react'
import { useAuth } from '../../context/AuthContext'
import { supabase } from '../../lib/supabase'
import { ChatBot } from '../Chat/ChatBot'
import { 
  Heart, 
  Users, 
  TrendingUp, 
  AlertTriangle,
  User,
  Calendar,
  MessageCircle,
  Search,
  Filter
} from 'lucide-react'

type Patient = {
  id: string
  full_name: string
  email: string
  phone: string
  date_of_birth: string
  latest_record?: {
    assessment_date: string
    heart_disease_risk_score: number
    blood_pressure_systolic: number
    blood_pressure_diastolic: number
    cholesterol_level: number
    bmi: number
  }
}

export const DoctorDashboard: React.FC = () => {
  const { profile, signOut } = useAuth()
  const [patients, setPatients] = useState<Patient[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<'patients' | 'chat'>('patients')
  const [searchTerm, setSearchTerm] = useState('')
  const [riskFilter, setRiskFilter] = useState<'all' | 'high' | 'moderate' | 'low'>('all')

  useEffect(() => {
    fetchPatients()
  }, [])

  const fetchPatients = async () => {
    try {
      // Get all patients with their latest medical records
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('*')
        .eq('role', 'patient')

      if (profilesError) throw profilesError

      const patientsWithRecords = await Promise.all(
        profiles.map(async (profile) => {
          const { data: records } = await supabase
            .from('medical_records')
            .select('*')
            .eq('patient_id', profile.id)
            .order('assessment_date', { ascending: false })
            .limit(1)

          return {
            ...profile,
            latest_record: records?.[0] || null
          }
        })
      )

      setPatients(patientsWithRecords)
    } catch (error) {
      console.error('Error fetching patients:', error)
    } finally {
      setLoading(false)
    }
  }

  const getRiskLevel = (score: number) => {
    if (score <= 5) return 'Low'
    if (score <= 10) return 'Moderate'
    if (score <= 15) return 'High'
    return 'Very High'
  }

  const getRiskColor = (score: number) => {
    if (score <= 5) return 'text-green-600 bg-green-100'
    if (score <= 10) return 'text-yellow-600 bg-yellow-100'
    if (score <= 15) return 'text-orange-600 bg-orange-100'
    return 'text-red-600 bg-red-100'
  }

  const filteredPatients = patients.filter(patient => {
    const matchesSearch = patient.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         patient.email.toLowerCase().includes(searchTerm.toLowerCase())
    
    if (!matchesSearch) return false

    if (riskFilter === 'all') return true
    if (!patient.latest_record) return false

    const riskLevel = getRiskLevel(patient.latest_record.heart_disease_risk_score)
    return riskLevel.toLowerCase() === riskFilter
  })

  const highRiskPatients = patients.filter(p => 
    p.latest_record && p.latest_record.heart_disease_risk_score > 10
  ).length

  const totalPatients = patients.length
  const averageRiskScore = patients.reduce((sum, p) => 
    sum + (p.latest_record?.heart_disease_risk_score || 0), 0
  ) / (patients.filter(p => p.latest_record).length || 1)

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Heart className="h-12 w-12 text-blue-600 mx-auto mb-4 animate-pulse" />
          <p className="text-gray-600">Loading patient data...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Heart className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">CardioHealth</span>
              <span className="ml-2 text-sm text-gray-500">Doctor Portal</span>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-sm text-gray-600">
                Dr. {profile?.full_name}
              </div>
              <button
                onClick={signOut}
                className="text-sm text-gray-600 hover:text-gray-900"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8">
            <button
              onClick={() => setActiveTab('patients')}
              className={`py-3 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'patients'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Patients
            </button>
            <button
              onClick={() => setActiveTab('chat')}
              className={`py-3 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'chat'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Medical Assistant
            </button>
          </div>
        </div>
      </nav>

      {/* Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'patients' && (
          <div className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <Users className="h-6 w-6 text-blue-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm text-gray-600">Total Patients</p>
                    <p className="text-2xl font-bold text-gray-900">{totalPatients}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center">
                  <div className="p-2 bg-red-100 rounded-lg">
                    <AlertTriangle className="h-6 w-6 text-red-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm text-gray-600">High Risk Patients</p>
                    <p className="text-2xl font-bold text-gray-900">{highRiskPatients}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center">
                  <div className="p-2 bg-green-100 rounded-lg">
                    <TrendingUp className="h-6 w-6 text-green-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm text-gray-600">Average Risk Score</p>
                    <p className="text-2xl font-bold text-gray-900">{averageRiskScore.toFixed(1)}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Search and Filter */}
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
                <div className="relative flex-1 max-w-md">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    placeholder="Search patients..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Filter className="h-5 w-5 text-gray-400" />
                  <select
                    value={riskFilter}
                    onChange={(e) => setRiskFilter(e.target.value as any)}
                    className="rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="all">All Risk Levels</option>
                    <option value="high">High Risk</option>
                    <option value="moderate">Moderate Risk</option>
                    <option value="low">Low Risk</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Patients List */}
            <div className="bg-white rounded-lg shadow">
              <div className="p-6 border-b">
                <h3 className="text-lg font-semibold text-gray-900">
                  Patients ({filteredPatients.length})
                </h3>
              </div>
              <div className="p-6">
                {filteredPatients.length === 0 ? (
                  <div className="text-center py-8">
                    <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">No patients found</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {filteredPatients.map((patient) => (
                      <div key={patient.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                        <div className="flex items-center space-x-4">
                          <div className="p-2 bg-blue-100 rounded-lg">
                            <User className="h-6 w-6 text-blue-600" />
                          </div>
                          <div>
                            <p className="font-medium text-gray-900">{patient.full_name}</p>
                            <p className="text-sm text-gray-600">{patient.email}</p>
                            <p className="text-sm text-gray-600">
                              Age: {patient.date_of_birth ? 
                                new Date().getFullYear() - new Date(patient.date_of_birth).getFullYear() : 
                                'N/A'
                              }
                            </p>
                          </div>
                        </div>
                        
                        <div className="text-right">
                          {patient.latest_record ? (
                            <div className="space-y-1">
                              <div className={`px-3 py-1 rounded-full text-sm font-medium ${getRiskColor(patient.latest_record.heart_disease_risk_score)}`}>
                                {getRiskLevel(patient.latest_record.heart_disease_risk_score)} Risk
                              </div>
                              <p className="text-sm text-gray-600">
                                Score: {patient.latest_record.heart_disease_risk_score}/20
                              </p>
                              <p className="text-sm text-gray-600">
                                BP: {patient.latest_record.blood_pressure_systolic}/{patient.latest_record.blood_pressure_diastolic}
                              </p>
                              <p className="text-xs text-gray-500">
                                {new Date(patient.latest_record.assessment_date).toLocaleDateString()}
                              </p>
                            </div>
                          ) : (
                            <div className="text-sm text-gray-500">
                              No assessment data
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'chat' && (
          <ChatBot />
        )}
      </main>
    </div>
  )
}