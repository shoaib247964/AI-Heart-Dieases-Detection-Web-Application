import React from 'react'
import { Heart, AlertCircle, CheckCircle, TrendingUp, Activity, Shield, Target } from 'lucide-react'

type ResultsDisplayProps = {
  result: {
    score: number
    risk: string
    recommendations: string
  }
  onReset: () => void
}

export const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ result, onReset }) => {
  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'Low':
        return {
          bg: 'from-green-500 to-emerald-600',
          text: 'text-green-600',
          bgLight: 'bg-green-50',
          icon: CheckCircle
        }
      case 'Moderate':
        return {
          bg: 'from-yellow-500 to-orange-500',
          text: 'text-yellow-600',
          bgLight: 'bg-yellow-50',
          icon: AlertCircle
        }
      case 'High':
        return {
          bg: 'from-orange-500 to-red-500',
          text: 'text-orange-600',
          bgLight: 'bg-orange-50',
          icon: AlertCircle
        }
      default:
        return {
          bg: 'from-red-500 to-red-700',
          text: 'text-red-600',
          bgLight: 'bg-red-50',
          icon: AlertCircle
        }
    }
  }

  const riskConfig = getRiskColor(result.risk)
  const RiskIcon = riskConfig.icon

  const getScorePercentage = () => (result.score / 20) * 100

  const recommendations = result.recommendations.split('.').filter(rec => rec.trim().length > 0)

  return (
    <div className="max-w-6xl mx-auto p-8">
      <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className={`bg-gradient-to-r ${riskConfig.bg} p-8 text-white`}>
          <div className="text-center">
            <div className="flex justify-center mb-6">
              <div className="p-4 bg-white/20 rounded-full backdrop-blur-sm">
                <RiskIcon className="h-16 w-16" />
              </div>
            </div>
            <h2 className="text-4xl font-bold mb-3">
              Assessment Complete
            </h2>
            <p className="text-xl opacity-90">
              Your comprehensive heart health analysis is ready
            </p>
          </div>
        </div>

        {/* Results Overview */}
        <div className="p-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
            {/* Risk Score Card */}
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl p-6 border-2 border-blue-200">
              <div className="text-center">
                <div className="flex justify-center mb-4">
                  <div className="relative w-24 h-24">
                    <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 100 100">
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        stroke="#e5e7eb"
                        strokeWidth="8"
                        fill="none"
                      />
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        stroke="#3b82f6"
                        strokeWidth="8"
                        fill="none"
                        strokeDasharray={`${getScorePercentage() * 2.51} 251`}
                        className="transition-all duration-1000 ease-out"
                      />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-2xl font-bold text-blue-600">{result.score}</span>
                    </div>
                  </div>
                </div>
                <h3 className="text-lg font-bold text-blue-800 mb-2">Risk Score</h3>
                <p className="text-blue-600">Out of 20 points</p>
              </div>
            </div>

            {/* Risk Level Card */}
            <div className={`bg-gradient-to-br ${riskConfig.bgLight} to-gray-50 rounded-2xl p-6 border-2 ${riskConfig.text.replace('text-', 'border-')}`}>
              <div className="text-center">
                <div className="flex justify-center mb-4">
                  <div className={`p-4 ${riskConfig.bgLight} rounded-full`}>
                    <RiskIcon className={`h-12 w-12 ${riskConfig.text}`} />
                  </div>
                </div>
                <h3 className="text-lg font-bold text-gray-800 mb-2">Risk Level</h3>
                <div className={`inline-block px-4 py-2 rounded-full text-lg font-bold ${riskConfig.text} ${riskConfig.bgLight}`}>
                  {result.risk} Risk
                </div>
              </div>
            </div>

            {/* Health Status Card */}
            <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-2xl p-6 border-2 border-purple-200">
              <div className="text-center">
                <div className="flex justify-center mb-4">
                  <div className="p-4 bg-purple-100 rounded-full">
                    <Heart className="h-12 w-12 text-purple-600" />
                  </div>
                </div>
                <h3 className="text-lg font-bold text-purple-800 mb-2">Health Status</h3>
                <p className="text-purple-600">
                  {result.risk === 'Low' ? 'Excellent' : 
                   result.risk === 'Moderate' ? 'Good' : 
                   result.risk === 'High' ? 'Needs Attention' : 'Requires Immediate Care'}
                </p>
              </div>
            </div>
          </div>

          {/* Detailed Analysis */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            {/* Risk Breakdown */}
            <div className="bg-gray-50 rounded-2xl p-6">
              <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                <TrendingUp className="h-6 w-6 mr-2 text-blue-600" />
                Risk Analysis
              </h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-white rounded-lg">
                  <span className="font-medium">Overall Risk Score</span>
                  <span className={`font-bold ${riskConfig.text}`}>{result.score}/20</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-white rounded-lg">
                  <span className="font-medium">Risk Category</span>
                  <span className={`font-bold ${riskConfig.text}`}>{result.risk}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-white rounded-lg">
                  <span className="font-medium">Percentile</span>
                  <span className="font-bold text-gray-700">{Math.round(getScorePercentage())}%</span>
                </div>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="bg-gray-50 rounded-2xl p-6">
              <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                <Activity className="h-6 w-6 mr-2 text-green-600" />
                Health Metrics
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-3 bg-white rounded-lg">
                  <div className="text-2xl font-bold text-blue-600 mb-1">
                    {result.risk === 'Low' ? '85%' : 
                     result.risk === 'Moderate' ? '70%' : 
                     result.risk === 'High' ? '55%' : '40%'}
                  </div>
                  <div className="text-sm text-gray-600">Heart Health</div>
                </div>
                <div className="text-center p-3 bg-white rounded-lg">
                  <div className="text-2xl font-bold text-green-600 mb-1">
                    {result.risk === 'Low' ? '92%' : 
                     result.risk === 'Moderate' ? '78%' : 
                     result.risk === 'High' ? '64%' : '50%'}
                  </div>
                  <div className="text-sm text-gray-600">Lifestyle Score</div>
                </div>
                <div className="text-center p-3 bg-white rounded-lg">
                  <div className="text-2xl font-bold text-purple-600 mb-1">
                    {result.risk === 'Low' ? '88%' : 
                     result.risk === 'Moderate' ? '72%' : 
                     result.risk === 'High' ? '58%' : '45%'}
                  </div>
                  <div className="text-sm text-gray-600">Prevention</div>
                </div>
                <div className="text-center p-3 bg-white rounded-lg">
                  <div className="text-2xl font-bold text-orange-600 mb-1">
                    {result.risk === 'Low' ? '95%' : 
                     result.risk === 'Moderate' ? '80%' : 
                     result.risk === 'High' ? '65%' : '52%'}
                  </div>
                  <div className="text-sm text-gray-600">Wellness</div>
                </div>
              </div>
            </div>
          </div>

          {/* Recommendations */}
          <div className="bg-gradient-to-br from-blue-50 to-teal-50 rounded-2xl p-8 mb-8">
            <h3 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
              <Target className="h-8 w-8 mr-3 text-blue-600" />
              Personalized Recommendations
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {recommendations.map((rec, index) => (
                <div key={index} className="flex items-start space-x-3 p-4 bg-white rounded-xl shadow-sm">
                  <div className="flex-shrink-0 w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mt-1">
                    <span className="text-blue-600 font-bold text-sm">{index + 1}</span>
                  </div>
                  <p className="text-gray-700 leading-relaxed">{rec.trim()}.</p>
                </div>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={onReset}
              className="px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-bold rounded-2xl transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              Take Another Assessment
            </button>
            <button
              onClick={() => window.print()}
              className="px-8 py-4 bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-700 hover:to-gray-800 text-white font-bold rounded-2xl transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              Print Results
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}