import React, { useState } from 'react'
import { AssessmentForm } from './components/HeartAssessment/AssessmentForm'
import { ResultsDisplay } from './components/Results/ResultsDisplay'
import { ChatBot } from './components/Chat/ChatBot'
import { PatientHistory } from './components/History/PatientHistory'
import { Heart, Activity, MessageCircle, Sparkles, Shield, TrendingUp } from 'lucide-react'

type AssessmentResult = {
  score: number
  risk: string
  recommendations: string
}

function App() {
  const [currentView, setCurrentView] = useState<'home' | 'assessment' | 'results' | 'chat' | 'history'>('home')
  const [assessmentResult, setAssessmentResult] = useState<AssessmentResult | null>(null)

  const handleAssessmentComplete = (result: AssessmentResult) => {
    setAssessmentResult(result)
    setCurrentView('results')
  }

  const handleReset = () => {
    setAssessmentResult(null)
    setCurrentView('home')
  }

  const renderContent = () => {
    switch (currentView) {
      case 'assessment':
        return <AssessmentForm onComplete={handleAssessmentComplete} />
      case 'results':
        return assessmentResult ? (
          <ResultsDisplay result={assessmentResult} onReset={handleReset} />
        ) : null
      case 'chat':
        return <ChatBot />
      case 'history':
        return <PatientHistory onTakeNewAssessment={() => setCurrentView('assessment')} />
      default:
        return (
          <div className="max-w-7xl mx-auto p-8">
            {/* Hero Section */}
            <div className="text-center mb-16">
              <div className="flex justify-center mb-8">
                <div className="p-6 bg-gradient-to-r from-blue-600 via-purple-600 to-teal-600 rounded-full shadow-2xl">
                  <Heart className="h-16 w-16 text-white" />
                </div>
              </div>
              <h1 className="text-6xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-teal-600 bg-clip-text text-transparent mb-6">
                CardioHealth AI
              </h1>
              <p className="text-2xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
                Advanced heart disease detection powered by artificial intelligence. 
                Get personalized risk assessments and expert recommendations for optimal cardiovascular health.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button
                  onClick={() => setCurrentView('assessment')}
                  className="px-8 py-4 bg-gradient-to-r from-blue-600 via-purple-600 to-teal-600 hover:from-blue-700 hover:via-purple-700 hover:to-teal-700 text-white font-bold rounded-2xl transition-all duration-300 transform hover:scale-105 shadow-xl"
                >
                  <div className="flex items-center space-x-3">
                    <Activity className="h-6 w-6" />
                    <span>Start Heart Assessment</span>
                  </div>
                </button>
                <button
                  onClick={() => setCurrentView('chat')}
                  className="px-8 py-4 bg-white hover:bg-gray-50 text-gray-800 font-bold rounded-2xl border-2 border-gray-200 hover:border-gray-300 transition-all duration-300 transform hover:scale-105 shadow-lg"
                >
                  <div className="flex items-center space-x-3">
                    <MessageCircle className="h-6 w-6" />
                    <span>Chat with AI Assistant</span>
                  </div>
                </button>
              </div>
            </div>

            {/* Features Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
              <div className="bg-white rounded-3xl p-8 shadow-xl border-2 border-gray-100 hover:shadow-2xl transition-all duration-300 transform hover:scale-105">
                <div className="flex justify-center mb-6">
                  <div className="p-4 bg-gradient-to-r from-blue-500 to-blue-600 rounded-2xl">
                    <Activity className="h-8 w-8 text-white" />
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mb-4 text-center">AI-Powered Assessment</h3>
                <p className="text-gray-600 text-center leading-relaxed">
                  Advanced machine learning algorithms analyze multiple health factors to provide accurate cardiovascular risk assessments.
                </p>
              </div>

              <div className="bg-white rounded-3xl p-8 shadow-xl border-2 border-gray-100 hover:shadow-2xl transition-all duration-300 transform hover:scale-105">
                <div className="flex justify-center mb-6">
                  <div className="p-4 bg-gradient-to-r from-purple-500 to-purple-600 rounded-2xl">
                    <Shield className="h-8 w-8 text-white" />
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mb-4 text-center">Personalized Recommendations</h3>
                <p className="text-gray-600 text-center leading-relaxed">
                  Receive tailored lifestyle recommendations and prevention strategies based on your unique health profile.
                </p>
              </div>

              <div className="bg-white rounded-3xl p-8 shadow-xl border-2 border-gray-100 hover:shadow-2xl transition-all duration-300 transform hover:scale-105">
                <div className="flex justify-center mb-6">
                  <div className="p-4 bg-gradient-to-r from-teal-500 to-teal-600 rounded-2xl">
                    <MessageCircle className="h-8 w-8 text-white" />
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mb-4 text-center">24/7 AI Assistant</h3>
                <p className="text-gray-600 text-center leading-relaxed">
                  Get instant answers to your heart health questions from our intelligent medical assistant, available anytime.
                </p>
              </div>
            </div>

            {/* Stats Section */}
            <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-teal-600 rounded-3xl p-12 text-white mb-16">
              <div className="text-center mb-8">
                <h2 className="text-4xl font-bold mb-4">Trusted by Healthcare Professionals</h2>
                <p className="text-xl opacity-90">Advanced cardiovascular risk assessment technology</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div className="text-center">
                  <div className="text-4xl font-bold mb-2">98%</div>
                  <div className="text-blue-100">Accuracy Rate</div>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold mb-2">50K+</div>
                  <div className="text-blue-100">Assessments Completed</div>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold mb-2">24/7</div>
                  <div className="text-blue-100">AI Support</div>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold mb-2">15+</div>
                  <div className="text-blue-100">Health Factors Analyzed</div>
                </div>
              </div>
            </div>

            {/* How It Works */}
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-gray-800 mb-12">How It Works</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="relative">
                  <div className="flex justify-center mb-6">
                    <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white text-2xl font-bold">
                      1
                    </div>
                  </div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">Complete Assessment</h3>
                  <p className="text-gray-600">
                    Fill out our comprehensive health questionnaire covering medical history, lifestyle, and symptoms.
                  </p>
                </div>
                <div className="relative">
                  <div className="flex justify-center mb-6">
                    <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-purple-600 rounded-full flex items-center justify-center text-white text-2xl font-bold">
                      2
                    </div>
                  </div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">AI Analysis</h3>
                  <p className="text-gray-600">
                    Our advanced AI algorithms analyze your data using the latest cardiovascular research and guidelines.
                  </p>
                </div>
                <div className="relative">
                  <div className="flex justify-center mb-6">
                    <div className="w-16 h-16 bg-gradient-to-r from-teal-500 to-teal-600 rounded-full flex items-center justify-center text-white text-2xl font-bold">
                      3
                    </div>
                  </div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">Get Results</h3>
                  <p className="text-gray-600">
                    Receive your personalized risk assessment with detailed recommendations and next steps.
                  </p>
                </div>
                <button
                  onClick={() => setCurrentView('history')}
                  className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                    currentView === 'history' 
                      ? 'bg-blue-100 text-blue-700' 
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                >
                  History
                </button>
              </div>
            </div>
          </div>
        )
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center cursor-pointer" onClick={() => setCurrentView('home')}>
              <Heart className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                CardioHealth AI
              </span>
            </div>
            <div className="flex items-center space-x-6">
              <button
                onClick={() => setCurrentView('home')}
                className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                  currentView === 'home' 
                    ? 'bg-blue-100 text-blue-700' 
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                Home
              </button>
              <button
                onClick={() => setCurrentView('assessment')}
                className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                  currentView === 'assessment' 
                    ? 'bg-blue-100 text-blue-700' 
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                Assessment
              </button>
              <button
                onClick={() => setCurrentView('chat')}
                className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                  currentView === 'chat' 
                    ? 'bg-blue-100 text-blue-700' 
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                AI Assistant
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="py-8">
        {renderContent()}
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex justify-center mb-6">
              <Heart className="h-8 w-8 text-blue-400" />
            </div>
            <h3 className="text-2xl font-bold mb-4">CardioHealth AI</h3>
            <p className="text-gray-400 mb-6 max-w-2xl mx-auto">
              Empowering individuals with AI-driven cardiovascular health insights for a healthier tomorrow.
            </p>
            <div className="flex justify-center space-x-6 text-sm text-gray-400">
              <span>© 2024 CardioHealth AI</span>
              <span>•</span>
              <span>Privacy Policy</span>
              <span>•</span>
              <span>Terms of Service</span>
              <span>•</span>
              <span>Contact</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App